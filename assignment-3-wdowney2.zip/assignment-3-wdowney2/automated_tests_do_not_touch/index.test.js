// ============================================
// LUNAR EATS — automated_tests_do_not_touch/tests.test.js
// ============================================

const fs = require("fs");
const path = require("path");

// Set up minimal DOM before loading the script
beforeEach(() => {
  document.body.innerHTML = `
    <div id="menu-container"></div>
    <div id="cart-container"><p class="cart-empty">Your cart is empty.</p></div>
    <button id="clear-cart-btn"></button>
    <button id="place-order-btn"></button>
    <div id="order-summary" class="hidden"></div>
  `;

  jest.resetModules();
});

let menuItems, cart, podNumber, renderMenu, updateCart, clearCart, placeOrder;

beforeEach(() => {
  ({
    menuItems,
    cart,
    podNumber,
    renderMenu,
    updateCart,
    clearCart,
    placeOrder,
  } = require("../index.js"));
});

// ============================================
// TASK 2 — renderMenu
// ============================================

describe("renderMenu()", () => {
  test("renders a card for every item in menuItems", () => {
    const cards = document.querySelectorAll(".menu-card");
    expect(cards.length).toBe(menuItems.length);
  });

  test("each card contains the item name", () => {
    const cards = document.querySelectorAll(".menu-card");
    cards.forEach((card, i) => {
      expect(card.textContent).toContain(menuItems[i].name);
    });
  });

  test("each card contains the item price", () => {
    const cards = document.querySelectorAll(".menu-card");
    cards.forEach((card, i) => {
      expect(card.textContent).toContain(String(menuItems[i].price));
    });
  });

  test("each card contains an Add to Cart button with the correct ID", () => {
    menuItems.forEach((item, i) => {
      const btn = document.querySelector(`#add-to-cart-${i}`);
      expect(btn).not.toBeNull();
    });
  });

  test("menuItems contains more than 7 items (student added their own)", () => {
    expect(menuItems.length).toBeGreaterThan(7);
  });
});

// ============================================
// TASK 3 — updateCart
// ============================================

describe("updateCart()", () => {
  test("adds an item to the cart array", () => {
    const item = menuItems[0];
    updateCart(item);
    expect(cart.length).toBe(1);
  });

  test("adds multiple items to the cart array", () => {
    updateCart(menuItems[0]);
    updateCart(menuItems[1]);
    expect(cart.length).toBe(2);
  });

  test("cart container updates to show the added item name", () => {
    const item = menuItems[0];
    updateCart(item);
    const cartContainer = document.querySelector("#cart-container");
    expect(cartContainer.textContent).toContain(item.name);
  });

  test("cart container updates to show the added item price", () => {
    const item = menuItems[0];
    updateCart(item);
    const cartContainer = document.querySelector("#cart-container");
    expect(cartContainer.textContent).toContain(String(item.price));
  });
});

// ============================================
// TASK 4 — clearCart
// ============================================

describe("clearCart()", () => {
  test("cart container shows empty message after clearing", () => {
    updateCart(menuItems[0]);
    clearCart();
    const cartContainer = document.querySelector("#cart-container");
    expect(cartContainer.textContent).toContain("Your cart is empty");
  });

  test("cart container no longer shows items after clearing", () => {
    updateCart(menuItems[0]);
    updateCart(menuItems[1]);
    clearCart();
    const cartContainer = document.querySelector("#cart-container");
    expect(cartContainer.textContent).not.toContain(menuItems[0].name);
    expect(cartContainer.textContent).not.toContain(menuItems[1].name);
  });
});

// ============================================
// TASK 5 — placeOrder
// ============================================

describe("placeOrder()", () => {
  test("order summary becomes visible after placing order", () => {
    updateCart(menuItems[0]);
    placeOrder();
    const orderSummary = document.querySelector("#order-summary");
    expect(orderSummary.classList.contains("hidden")).toBe(false);
  });

  test("order summary contains the pod number", () => {
    updateCart(menuItems[0]);
    placeOrder();
    const orderSummary = document.querySelector("#order-summary");
    expect(orderSummary.textContent).toContain(podNumber);
  });

  test("order summary contains the correct total", () => {
    updateCart(menuItems[0]);
    updateCart(menuItems[1]);
    const expectedTotal = menuItems[0].price + menuItems[1].price;
    placeOrder();
    const orderSummary = document.querySelector("#order-summary");
    expect(orderSummary.textContent).toContain(String(expectedTotal));
  });
});
