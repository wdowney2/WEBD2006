// ============================================
// LUNAR EATS — index.js
// ============================================

// --------------------------------------------
// TASK 1 — Set your pod number
// --------------------------------------------

// Set your moon pod delivery address here (any string you like, e.g. "Pod 42-B")
const podNumber = "X-640";

// --------------------------------------------
// CART
// --------------------------------------------

// This array will hold the items the user adds to their cart
let cart = [];

// --------------------------------------------
// MENU DATA
// --------------------------------------------

const menuItems = [
  {
    name: "Dark Side Burger",
    description:
      "A crater-pressed patty with lunar cheese and meteor sauce, served on a gravity-defying bun.",
    price: 18,
    category: "Mains",
    imageSrc: "images/dark-side-burger.jpg",
    ingredients: [
      "beef patty",
      "lunar cheese",
      "meteor sauce",
      "space bun",
      "lettuce",
    ],
    nutrition: {
      calories: 820,
      protein: 45,
    }
  },
  {
    name: "Rocket Fuel Ramen",
    description:
      "A steaming bowl of zero-gravity noodles in a rich asteroid broth with dehydrated vegetables.",
    price: 16,
    category: "Mains",
    imageSrc: "images/rocket-fuel-ramen.jpg",
    ingredients: [
      "noodles",
      "asteroid broth",
      "dehydrated vegetables",
      "moon egg",
      "nori",
    ],
    nutrition: {
      calories: 540,
      protein: 22,
    }
  },
  {
    name: "Meteor Fries",
    description: "Crispy crater-cut fries dusted with stardust seasoning.",
    price: 8,
    category: "Sides",
    imageSrc: "images/meteor-fries.jpg",
    ingredients: ["potatoes", "stardust seasoning", "solar salt"],
    nutrition: {
      calories: 380,
      protein: 5,
    }
  },
  {
    name: "Moonbase Salad",
    description: "Hydroponically grown greens with nebula vinaigrette.",
    price: 10,
    category: "Sides",
    imageSrc: "images/moonbase-salad.jpg",
    ingredients: [
      "mixed greens",
      "cherry tomatoes",
      "cucumber",
      "nebula vinaigrette",
    ],
    nutrition: {
      calories: 120,
      protein: 3,
    }
  },
  {
    name: "Comet Tail Lemonade",
    description: "A sparkling citrus drink with a streak of blue lunar syrup.",
    price: 6,
    category: "Drinks",
    imageSrc: "images/comet-tail-lemonade.jpg",
    ingredients: ["lemon juice", "lunar syrup", "sparkling water", "ice"],
    nutrition: {
      calories: 180,
      protein: 0,
    }
  },
  {
    name: "Galactic Cold Brew",
    description: "Slow-steeped dark matter coffee served over moon ice.",
    price: 7,
    category: "Drinks",
    imageSrc: "images/galactic-cold-brew.jpg",
    ingredients: ["dark matter coffee", "moon ice", "oat milk"],
    nutrition: {
      calories: 90,
      protein: 2,
    }
  },
  {
    name: "Crescent Cheesecake",
    description:
      "A silky cheesecake shaped like a crescent moon with stardust sugar glaze.",
    price: 12,
    category: "Desserts",
    imageSrc: "images/crescent-cheesecake.jpg",
    ingredients: ["cream cheese", "graham crust", "stardust sugar", "vanilla"],
    nutrition: {
      calories: 460,
      protein: 8,
    }
  },

  // TASK 1 — Add your own dessert object here.
  // It must include all of the same properties as the items above:
  // name, description, price, category, imageSrc, ingredients, and nutrition.
  //
  // For imageSrc, you can use "images/placeholder.jpg" or find your own image,
  // add it to the images folder, and use its filename here.


  {
    name: "Placeholder Pie",
    description:
      "It's 640x640!",
    price: 640,
    category: "Desserts",
    imageSrc: "images/placeholder.jpg",
    ingredients: ["640", "x", "640", "placeholder"],
    nutrition: {
      calories: 640,
      protein: 640,
    }
  }
];

// --------------------------------------------
// TASK 2 — renderMenu()
// --------------------------------------------

// Loops through the menuItems array and displays each item as a card on the page.
//
// Each card should look something like this:
//
// <div class="menu-card">
//   <img src="IMAGE_SRC_GOES_HERE" alt="ITEM_NAME_GOES_HERE" />
//   <div class="menu-card-body">
//     <p class="menu-card-category">CATEGORY_GOES_HERE</p>
//     <h3 class="menu-card-name">ITEM_NAME_GOES_HERE</h3>
//     <p class="menu-card-description">DESCRIPTION_GOES_HERE</p>
//     <p class="menu-card-nutrition">CALORIES_GOES_HERE cal | PROTEIN_GOES_HERE g protein</p>
//     <div class="menu-card-footer">
//       <span class="menu-card-price">PRICE_GOES_HERE LC</span>
//       <button class="btn-add" id="add-to-cart-INDEX_GOES_HERE">Add to Cart</button>
//     </div>
//   </div>
// </div>
//
// Note the button ID — it uses the item's index in the array (e.g. add-to-cart-0, add-to-cart-1).
// You will use this ID after inserting the cards to attach click listeners.

function renderMenu() {
  const menuContainer = document.querySelector("#menu-container");

  // Loop 1: build and insert all card HTML
  for (let i = 0; i < menuItems.length; i++) {
    // Build the card HTML string for the current item using a template literal
    // and add it to the menuContainer

    // append pre-provided html to existing list
    menuContainer.innerHTML = menuContainer.innerHTML + `
    <div class="menu-card">
      <img src="${menuItems[i].imageSrc}" alt="${menuItems[i].name}" />
      <div class="menu-card-body">
        <p class="menu-card-category">${menuItems[i].category}</p>
        <h3 class="menu-card-name">${menuItems[i].name}</h3>
        <p class="menu-card-description">${menuItems[i].description}</p>
        <p class="menu-card-nutrition">${menuItems[i].nutrition.calories} cal | ${menuItems[i].nutrition.protein} g protein</p>
        <div class="menu-card-footer">
          <span class="menu-card-price">${menuItems[i].price} LC</span>
          <button class="btn-add" id="add-to-cart-${i}">Add to Cart</button>
        </div>
      </div>
    </div>`;
  }

  // Loop 2: attach click listeners to each Add to Cart button
  for (let i = 0; i < menuItems.length; i++) {
    // Add a click listener to btn that calls updateCart() with the current menu item
    document.querySelector(`#add-to-cart-${i}`).addEventListener("click", (e) => { updateCart(i) }); // This loop is one line and you just gave me half of it for free. Thanks!
  }
}

// --------------------------------------------
// TASK 3 — updateCart(item)
// --------------------------------------------

// Receives a single menu item object, adds it to the cart array,
// then re-renders the cart display by looping through the cart array
// and adding each item to the cart container.
//
// Each cart item should look something like this:
//
// <div class="cart-item">
//   <span class="cart-item-name">ITEM_NAME_GOES_HERE</span>
//   <span class="cart-item-price">ITEM_PRICE_GOES_HERE LC</span>
// </div>
//
// Hint: clear the current cart display before re-rendering
// Hint: the cart container is #cart-container

function updateCart(item) {
  // Add item to the cart array
  cart.push(item);
  // Re-render the cart display by looping through the cart array
  const cartContainer = document.querySelector("#cart-container");
  let cartHTML = ""; // it needs to build the whole string and *then* replace the cart HTML with that because that's the easiest way to get rid of the empty cart message
  cart.forEach(element => {
    cartHTML = cartHTML + `
    <div class="cart-item">
      <span class="cart-item-name">${menuItems[element].name}</span>
      <span class="cart-item-price">${menuItems[element].price} LC</span>
    </div>`;
  });
  cartContainer.innerHTML = cartHTML;
}

// --------------------------------------------
// TASK 4 — clearCart()
// --------------------------------------------

// Empties the cart array and resets the cart display.
//
// The empty cart message should look like this:
//
// <p class="cart-empty">Your cart is empty.</p>
//
// Hint: the cart container is #cart-container

function clearCart() {
  // Reset the cart array
  cart = [];
  // Reset the cart display to show the empty cart message
  document.querySelector("#cart-container").innerHTML = '<p class="cart-empty">Your cart is empty.</p>';
}

// --------------------------------------------
// TASK 5 — placeOrder()
// --------------------------------------------

// Displays the order summary with a confirmation message, the pod number, and the total cost.
// Make the order summary container visible by removing the "hidden" class.
//
// The order summary should look something like this:
//
// <p class="order-summary-title">Order on its way!</p>
// <p class="order-summary-detail">Delivering to: POD_NUMBER_GOES_HERE</p>
// <p class="order-summary-total">Total: TOTAL_GOES_HERE LC</p>
//
// Hint: the order summary container is #order-summary

function placeOrder() {
  // Calculate the total cost by looping through the cart array
  // Build the summary HTML and update the order summary container
  // Make the order summary visible by removing the "hidden" class
  let cost = 0;
  cart.forEach(element => { // goes through the cart, adds the price of each entry to the total
    cost += menuItems[element].price;
  });
  orderSummary = document.querySelector("#order-summary");
  orderSummary.innerHTML = `
  <p class="order-summary-title">Order on its way!</p>
  <p class="order-summary-detail">Delivering to: ${podNumber}</p>
  <p class="order-summary-total">Total: ${cost} LC</p>`;
  orderSummary.classList.remove("hidden");
}

// --------------------------------------------
// BUTTON EVENT LISTENERS
// --------------------------------------------

// Wire up the Clear Cart button
// Hint: select the button by its ID and add a click listener that calls clearCart()

document.querySelector("#clear-cart-btn").addEventListener("click", (e) => { clearCart() });

// Wire up the Place Order button
// Hint: select the button by its ID and add a click listener that calls placeOrder()

document.querySelector("#place-order-btn").addEventListener("click", (e) => { placeOrder() });

// --------------------------------------------
// START
// --------------------------------------------

renderMenu();

// ============================================
// DO NOT CHANGE THE FOLLOWING LINES
// THEY ARE FOR AUTOMATED TESTING PURPOSES
// ============================================
module.exports = {
  menuItems,
  cart,
  podNumber,
  renderMenu,
  updateCart,
  clearCart,
  placeOrder,
};
