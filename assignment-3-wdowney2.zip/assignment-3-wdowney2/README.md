# 🌙 Lunar Eats — Moon Pod Delivery

## Overview

Welcome to Lunar Eats, the moon's premier food delivery service. Hungry astronauts across the lunar surface are counting on you to build their online ordering system. You've been given the restaurant's menu data and an HTML shell — your job is to bring it to life with JavaScript.

## Prerequisites

Before starting, make sure you have:
- VS Code installed with the Live Server extension
- Git installed and configured
- A GitHub account
- Google Chrome or Firefox with DevTools

## Getting Started

1. Accept the assignment via the link on Brightspace
2. Clone the repository to your local machine
3. Open the project in VS Code
4. Update the `README.md` with your name below
5. Open `index.html` with Live Server and confirm the page loads
6. Commit and push your changes

**Student Name:** *(replace this with your name)*

> 💡 All of your work goes in `index.js`. You do not need to modify `index.html`.

---

## Automated Tests

This assignment includes automated tests that run every time you push to GitHub. You can view the results by clicking the **Actions** tab in your GitHub repository.

> ⚠️ Tests are provided as a guide to help you check your work — they are not directly tied to your grade. Passing all tests is a good sign, but your submission will still be reviewed manually using the rubric below.

**Optional: Running tests locally**

If you're curious, you can also run the tests on your own machine. Note that we haven't covered Node.js or npm in this course yet — this is purely optional and not required.

1. Install [Node.js](https://nodejs.org) if you don't have it
2. In your project folder, run `npm install`
3. Then run `npm test`

---

## The Data

The `menuItems` array is already provided in `index.js`. Each item in the array is an object with the following properties:

- `name` — the name of the menu item
- `description` — a short description
- `price` — price in lunar credits (a number)
- `category` — one of: `"Mains"`, `"Sides"`, `"Drinks"`, `"Desserts"`
- `imageSrc` — path to the item's image
- `ingredients` — an array of ingredient strings
- `nutrition` — a nested object with `calories` and `protein` properties

Take a few minutes to read through the data before you start writing any code.

---

## Instructions

Your job is to complete five tasks in `index.js`. The starter file includes the menu data, a declared `podNumber` variable, and function stubs for each feature. Read through the starter file carefully before you begin — the comments will guide you on what each function should do and what the HTML structure of your output should look like.

### Task 1 — Set Up Your Order

Before building any features, complete two setup steps in `index.js`:

**1a. Add your own dessert to the menu.**

A comment in the starter file shows you the shape of a menu item object. Add a new dessert of your own invention to the `menuItems` array. It must include all properties listed above — name, description, price, category, imageSrc, ingredients, and nutrition.

For the image, you can use the included `placeholder.jpg` or find your own image and add it to the project folder.

**1b. Set your pod number.**

A variable called `podNumber` is declared near the top of `index.js`. Set it to your moon pod delivery address — any string you like (e.g. `"Pod 42-B"`).

---

### Task 2 — Render the Menu

Display all menu items on the page by generating HTML from the `menuItems` array.

A comment in `index.js` shows you what a single menu card should look like. Each card should include the item's image, name, category, description, price, calorie count, protein count, and an **Add to Cart** button.

Use `innerHTML` and template literals to build the cards and insert them into the menu container on the page.

> 💡 Check the HTML comments in `index.html` to see where your cards should appear.

---

### Task 3 — Add to Cart

When a user clicks **Add to Cart** on a menu item, that item should be added to a cart array and the cart display on the page should update.

The cart display should show each item in the cart with its name and price.

> 💡 Each **Add to Cart** button has a unique ID based on its position in the array (e.g. `add-to-cart-0`, `add-to-cart-1`). After inserting each card into the page, use that ID to select the button and attach a click listener to it — right there in the same loop.

---

### Task 4 — Clear Cart

The cart display should include a **Clear Cart** button. When clicked, the cart array should be emptied and the cart display should update to reflect the empty cart.

---

### Task 5 — Place Order

When the user clicks the **Place Order** button, display an order summary on the page. The summary should include:
- A confirmation message (e.g. "Order on its way!")
- The pod number from Task 1
- The total cost of all items in the cart

> 💡 Check the HTML comments in `index.html` to see where the order summary should appear.

---

## Submitting

Commit and push your work regularly as you complete each task. Each commit should reflect meaningful progress on your solution. Do not save everything for one final commit.

---

## Rubric

This assignment is marked out of 15.

| Criterion | Points | Descriptor |
|---|---|---|
| **Task 1 — Set Up Your Order** | 1 | New menu item includes all required properties and pod number is set |
| | 0 | Setup incomplete or missing |
| **Task 2 — Render Menu** | 4 | All items render with all required properties; innerHTML and template literals used correctly |
| | 3 | All items render but one required property is missing or displays incorrectly |
| | 2 | Some items render correctly; significant issues with data access or template structure |
| | 1 | Attempted but menu does not render meaningfully |
| | 0 | Not implemented |
| **Task 3 — Add to Cart** | 4 | Event listeners correctly attached to each button; items added to cart array; display updates with item name and price |
| | 3 | Event listeners correctly attached and items added to array; display updates but name or price missing |
| | 2 | Event listeners correctly attached and items added to array; display does not update |
| | 1 | Attempted but event listeners not correctly attached or cart does not function meaningfully |
| | 0 | Not implemented |
| **Task 4 — Clear Cart** | 2 | Cart array correctly emptied and display updates to reflect empty cart |
| | 1 | Cart clears but display does not update, or display clears but array is not reset |
| | 0 | Not implemented |
| **Task 5 — Place Order** | 2 | Order summary displays confirmation message, pod number, and correct total cost |
| | 1 | Order summary appears but is missing one or more required elements |
| | 0 | Not implemented |
| **Code Quality** | 2 | Descriptive variable names, clear comments, and consistent formatting throughout |
| | 1 | Some quality issues — unclear naming, missing comments, or inconsistent formatting |
| | 0 | Code quality requirements not met |

---

## Academic Integrity

### Use of Generative AI Tools in the Classroom
**USE NOT PERMITTED**

For the assignments/assessments in this course, the use of any Generative Artificial Intelligence (AI) tools is not permitted. The assignments/assessments are intended to measure each student's ability to generate their own work. Your unique comprehension and interpretation of the course content must be demonstrated in order to be successful. Using prohibited resources will be considered academic misconduct and be addressed following SR 1.3 Academic Integrity Procedure.

---

## Incremental Development

You must demonstrate incremental development of your solution. This means that you must begin work on your solution as soon as possible and commit often to the assignment repository. Each commit must demonstrate functional improvements to the solution. Just like in a professional environment, leaving a task untouched until right before the deadline is not acceptable — start early and make consistent progress. Failure to show incremental work during the assignment period will result in loss of marks of up to 20%.

---
 
## Credits
 
Menu images generated using [DeepAI Text to Image](https://deepai.org/machine-learning-model/text2img).
 