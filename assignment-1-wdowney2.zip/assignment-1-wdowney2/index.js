// =====================================================
// Realm of the Soggy Goblin - Character Calculator
// =====================================================

// ======================
// PART 2: Fix the Bugs
// ======================
// There are 3 bugs below. Fix each one and add a comment
// above your fix explaining what was wrong.

// Bug 1
// -- Variable declaration was missing --
const characterName = prompt("What is your character's name, adventurer?");

// Bug 2
// -- extraLevels needs to be converted to a number for calculation --
const baseLevel = 10;
const extraLevels = Number(prompt("You've leveled up! How many extra levels did you gain?"));
const totalLevel = baseLevel + extraLevels;
console.log("Total level: " + totalLevel);

// Bug 3
// -- typo --
const greeting = `Hail, ${characterName}! You have reached level ${totalLevel}.`;
console.log(greeting);


// ======================
// PART 3: Complete the Code
// ======================

// TODO A: Prompt the user for their base strength and store it in a variable called strength
// Use this exact prompt string: "Choose your starting strength (1-20):"

const strength = Number(prompt("Choose your starting strength (1-20):"));

// TODO B: Calculate the following stats:
// - hp = totalLevel * 10
// - powerScore = (strength * 2) + hp

const hp = totalLevel * 10;
const powerScore = (strength * 2) + hp;

// TODO C: Log the character summary using a single console.log
// Hint: you can use a multi-line template literal to format it nicely
// https://www.w3schools.com/js/js_string_templates.asp
//
// Expected output (with your character's values filled in):
//
//   ==============================
//   CHARACTER SUMMARY
//   ==============================
//   Name: <CHARACTER NAME>
//   Level: <LEVEL>
//   Strength: <STRENGTH>
//   HP: <HP>
//   Power Score: <POWER SCORE>
//   ==============================

console.log(`==============================
CHARACTER SUMMARY
==============================
Name: ${characterName}
Level: ${totalLevel}
Strength: ${strength}
HP: ${hp}
Power Score: ${powerScore}
==============================`);