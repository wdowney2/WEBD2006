/**
 * WEBD2006 - Assignment 1 Tests
 * Realm of the Soggy Goblin - Character Calculator
 *
 * Test values:
 *   name: "Aldric"
 *   extraLevels: 3
 *   strength: 8
 *
 * Expected results:
 *   totalLevel: 13
 *   hp: 130
 *   powerScore: 146
 */

let consoleSpy;
let logs;

beforeEach(() => {
  // Mock prompt() with predetermined values
  let promptCallCount = 0;
  const promptValues = ["Aldric", "3", "8"];
  global.prompt = jest.fn(() => promptValues[promptCallCount++]);

  // Capture console.log output
  logs = [];
  consoleSpy = jest.spyOn(console, "log").mockImplementation((...args) => {
    logs.push(args.join(" "));
  });

  // Reset and re-run the student's script before each test
  jest.resetModules();
  require("../index.js");
});

afterEach(() => {
  consoleSpy.mockRestore();
});

// --- Part 2: Bug Fixes ---

test("Bug 1 — characterName is declared before use (no ReferenceError)", () => {
  // If the script loaded without throwing, Bug 1 is fixed
  expect(logs.some((log) => log.includes("Aldric"))).toBe(true);
});

test("Bug 2 — totalLevel is a number, not a string", () => {
  const totalLevelLog = logs.find((log) => log.includes("Total level:"));
  expect(totalLevelLog).toBe("Total level: 13");
});

test("Bug 3 — greeting uses correct variable name (no undefined)", () => {
  const greetingLog = logs.find((log) => log.includes("Hail,"));
  expect(greetingLog).toBe("Hail, Aldric! You have reached level 13.");
});

// --- Part 3: TODOs ---

test("TODO A — strength is parsed as a number", () => {
  const summaryLog = logs.find((log) => log.includes("Strength:"));
  expect(summaryLog).toBeTruthy();
  expect(summaryLog).toContain("Strength: 8");
});

test("TODO B — hp and powerScore are calculated correctly", () => {
  const summaryLog = logs.find((log) => log.includes("CHARACTER SUMMARY"));
  expect(summaryLog).toContain("HP: 130");
  expect(summaryLog).toContain("Power Score: 146");
});

test("TODO C — character summary is logged to the console", () => {
  const summaryLog = logs.find((log) => log.includes("CHARACTER SUMMARY"));
  expect(summaryLog).toBeTruthy();
  expect(summaryLog).toContain("Name: Aldric");
  expect(summaryLog).toContain("Level: 13");
});
