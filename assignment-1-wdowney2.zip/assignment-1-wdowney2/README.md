# ⚔️ Realm of the Soggy Goblin — Character Calculator

## Overview

The previous developers working on *Realm of the Soggy Goblin* — a bold new text-based adventure game — were fired because they wrote code full of bugs. You've been brought in to fix their mess and implement the missing features of the character creator. Good luck, adventurer.

## Prerequisites

Before starting, make sure you have:
- VS Code installed
- Git installed and configured
- A GitHub account
- Google Chrome or Firefox with DevTools

## Getting Started

1. Accept the assignment via the link on Brightspace
2. Clone the repository to your local machine
3. Open the project in VS Code
4. Update the `README.md` with your name below
5. Link `index.js` in `index.html`
6. Commit and push your changes

**Student Name:** *Willem*

> 💡 Open `index.html` with Live Server in VS Code and use the DevTools console in your browser to run and test your code.

---

## Automated Tests

This assignment includes automated tests that run every time you push to GitHub. You can view the results by clicking the **Actions** tab in your GitHub repository.

> ⚠️ Tests are provided as a guide to help you check your work — they are not directly tied to your grade. Passing all tests is a good sign, but your submission will still be reviewed manually using the rubric below.

**Optional: Running tests locally**

If you're curious, you can also run the tests on your own machine. Note that we haven't covered Node.js or npm in this course yet — this is purely optional and not required.

1. Install [Node.js](https://nodejs.org) if you don't have it
2. In your project folder, run `npm install`
3. Then run `npm test`

---

## Instructions

### Part 1 — Setup
- Accept and clone the repository
- Update the README with your name
- Link `index.js` in `index.html`
- ✅ **Commit your changes**

### Part 2 — Fix the Bugs

There are 3 bugs in `index.js`. Find and fix each one. Above each fix, add a comment explaining what was wrong.

- ✅ **Commit after fixing Bug 1**
- ✅ **Commit after fixing Bug 2**
- ✅ **Commit after fixing Bug 3**

### Part 3 — Complete the Code

Complete the three TODOs in `index.js` to finish the character creator.

- **TODO A:** Prompt the user for their character's base strength
- **TODO B:** Calculate the character's stats
- **TODO C:** Log the character summary to the console

- ✅ **Commit after completing TODO A**
- ✅ **Commit after completing TODO B**
- ✅ **Commit after completing TODO C**

---

## Rubric

This assignment is marked out of 10.

| Criterion | Full | Partial | None |
|---|---|---|---|
| **Code Completion (4 pts)** | All three TODOs correctly implemented and producing expected output (4 pts) | All three attempted, minor errors in one (3 pts); Two TODOs correct (2 pts); One TODO correct (1 pt) | No TODOs correctly implemented (0 pts) |
| **Bug Fixes (3 pts)** | All three bugs fixed and documented with a comment (3 pts) | Two fixed and documented, or all three fixed but undocumented (2 pts); Two fixed but undocumented, or one fixed and documented (1 pt) | No bugs correctly fixed (0 pts) |
| **Git & Commits (2 pts)** | At least one commit per checkpoint with meaningful messages (2 pts) | Some checkpoints missing or messages vague/unhelpful (1 pt) | No meaningful commit history present (0 pts) |
| **Code Quality (1 pt)** | Readable code with descriptive variable names and clear comments (1 pt) | — | Code quality requirements not met (0 pts) |

---

## Academic Integrity

### Use of Generative AI Tools in the Classroom
**USE NOT PERMITTED**

For the assignments/assessments in this course, the use of any Generative Artificial Intelligence (AI) tools is not permitted. The assignments/assessments are intended to measure each student's ability to generate their own work. Your unique comprehension and interpretation of the course content must be demonstrated in order to be successful. Using prohibited resources will be considered academic misconduct and be addressed following SR 1.3 Academic Integrity Procedure.

---

## Incremental Development

You must demonstrate incremental development of your solution. This means that you must begin work on your solution as soon as possible and commit often to the assignment repository. Each commit must demonstrate functional improvements to the solution. Just like in a professional environment, leaving a task untouched until right before the deadline is not acceptable — start early and make consistent progress. Failure to show incremental work during the assignment period will result in loss of marks of up to 20%.
